var Meta = imports.gi.Meta;
var ExtensionUtils = imports.misc.extensionUtils;

var _windowCreatedId;
var _settings;

const Util = imports.misc.util;
const Shell = imports.gi.Shell;


function init() {
    _settings = ExtensionUtils.getSettings();
}

function enable() {
    // window-created
    _windowFocusId = global.display.connect('notify::focus-window', (d, win) => {
        // global.log("gnome-extension WindowExec@darkretailer.github.com: Window " + win.gtk_application_id);
        // global.log(Shell.WindowTracker.get_default().focus_app.get_id());
        // global.log(Shell.WindowTracker.get_default().focus_app.get_name());
        // global.log(Shell.WindowTracker.get_default().focus_app.get_windows()[0].get_title());
        Util.spawn(['/bin/bash', '-c', 
            '~/.local/share/gnome-shell/extensions/XBindKeys@darkretailer.github.com/xbindkeys_exec.sh "' 
            + Shell.WindowTracker.get_default().focus_app.get_id() 
            + '" "' + Shell.WindowTracker.get_default().focus_app.get_name() 
            + '" "' + Shell.WindowTracker.get_default().focus_app.get_windows()[0].get_title() + '"']);
    });
}

function disable() {
    global.display.disconnect(_windowCreatedId);
    _windowFocusId = null;
} 
